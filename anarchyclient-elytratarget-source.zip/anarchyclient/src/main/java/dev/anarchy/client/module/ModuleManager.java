package dev.anarchy.client.module;

import dev.anarchy.client.module.impl.*;
import dev.anarchy.client.config.ClientConfig;
import dev.anarchy.client.gui.ClickGuiScreen;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ModuleManager {
    private static final KeyBinding.Category CATEGORY =
            KeyBinding.Category.create(Identifier.of("anarchyclient", "main"));

    private final List<Module> modules = new ArrayList<>();
    private final Map<Module, KeyBinding> keys = new LinkedHashMap<>();
    private KeyBinding clickGuiKey;

    public void init() {
        ClientConfig.load();
        clickGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.anarchyclient.clickgui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, CATEGORY));
        add(new CrystalAuraModule(), GLFW.GLFW_KEY_C);
        add(new FlyModule(), GLFW.GLFW_KEY_G);
        add(new SpeedModule(), GLFW.GLFW_KEY_H);
        add(new NoFallModule(), GLFW.GLFW_KEY_N);
        add(new FullbrightModule(), GLFW.GLFW_KEY_B);
        add(new SprintModule(), GLFW.GLFW_KEY_V);
        add(new ElytraTargetModule(), GLFW.GLFW_KEY_J);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (clickGuiKey.wasPressed()) client.setScreen(new ClickGuiScreen(this));
            if (client.player == null) return;
            for (var e : keys.entrySet()) {
                while (e.getValue().wasPressed()) {
                    e.getKey().toggle();
                    client.player.sendMessage(Text.literal("§7[AC] §f" + e.getKey().getName()
                            + (e.getKey().isEnabled() ? " §aON" : " §cOFF")), true);
                }
            }
            for (Module m : modules) if (m.isEnabled()) m.onTick();
        });

        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.of("anarchyclient", "modules"), (ctx, tickCounter) -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    if (mc.options.hudHidden) return;
                    int accent = ClientConfig.accent;
                    int y = 5;
                    if (ClientConfig.showFps) {
                        ctx.drawTextWithShadow(mc.textRenderer, "FPS: " + mc.getCurrentFps(), 6, y, accent); y += 11;
                    }
                    if (ClientConfig.showCoords && mc.player != null) {
                        var p = mc.player.getBlockPos();
                        ctx.drawTextWithShadow(mc.textRenderer, "XYZ: " + p.getX() + " / " + p.getY() + " / " + p.getZ(), 6, y, accent); y += 11;
                    }
                    if (ClientConfig.showKeystrokes && mc.player != null) {
                        String keysText = (mc.options.forwardKey.isPressed() ? "W" : "·") + " " +
                                (mc.options.leftKey.isPressed() ? "A" : "·") + " " +
                                (mc.options.backKey.isPressed() ? "S" : "·") + " " +
                                (mc.options.rightKey.isPressed() ? "D" : "·");
                        ctx.fill(5, y, 62, y + 13, 0x990D111B);
                        ctx.drawTextWithShadow(mc.textRenderer, keysText, 9, y + 3, accent); y += 16;
                    }
                    if (ClientConfig.showArmor && mc.player != null) {
                        ctx.drawTextWithShadow(mc.textRenderer, "ARMOR: " + mc.player.getArmor(), 6, y, accent); y += 11;
                    }
                    for (Module m : modules) {
                        if (!m.isEnabled()) continue;
                        ctx.drawTextWithShadow(mc.textRenderer, m.getName(), 6, y, 0xFFE5E7EB);
                        y += 10;
                    }
                });
    }

    private void add(Module m, int key) {
        modules.add(m);
        KeyBinding kb = new KeyBinding("key.anarchyclient." + m.getName().toLowerCase(),
                InputUtil.Type.KEYSYM, key, CATEGORY);
        keys.put(m, KeyBindingHelper.registerKeyBinding(kb));
    }

    public List<Module> getModules() { return modules; }

    public void rebind(Module module, int keyCode) {
        KeyBinding binding = keys.get(module);
        if (binding == null) return;
        binding.setBoundKey(InputUtil.fromKeyCode(keyCode, 0));
        KeyBinding.updateKeysByCode();
    }

    public String getKeyName(Module module) {
        KeyBinding binding = keys.get(module);
        return binding == null ? "-" : binding.getBoundKeyLocalizedText().getString();
    }
}
