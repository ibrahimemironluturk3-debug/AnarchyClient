package dev.anarchy.client.config;

import java.io.*;
import java.nio.file.*;
import java.util.Properties;

public final class ClientConfig {
    private static final Path FILE = Path.of("config", "anarchyclient.properties");
    public static int accent = 0xFF8B5CF6;
    public static boolean rainbow = false;
    public static boolean showFps = true;
    public static boolean showCoords = true;
    public static boolean showKeystrokes = true;
    public static boolean showArmor = true;
    public static boolean elytraAutoFire = true;
    public static int elytraRange = 48;
    public static int elytraLeadTicks = 6;
    private ClientConfig() {}

    public static void load() {
        Properties p = new Properties();
        if (!Files.exists(FILE)) return;
        try (InputStream in = Files.newInputStream(FILE)) {
            p.load(in);
            accent = (int) Long.parseLong(p.getProperty("accent", Integer.toUnsignedString(accent)), 16);
            rainbow = Boolean.parseBoolean(p.getProperty("rainbow", "false"));
            showFps = Boolean.parseBoolean(p.getProperty("fps", "true"));
            showCoords = Boolean.parseBoolean(p.getProperty("coords", "true"));
            showKeystrokes = Boolean.parseBoolean(p.getProperty("keys", "true"));
            showArmor = Boolean.parseBoolean(p.getProperty("armor", "true"));
            elytraAutoFire = Boolean.parseBoolean(p.getProperty("elytraAutoFire", "true"));
            elytraRange = Integer.parseInt(p.getProperty("elytraRange", "48"));
            elytraLeadTicks = Integer.parseInt(p.getProperty("elytraLeadTicks", "6"));
        } catch (Exception ignored) {}
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("accent", String.format("%08X", accent));
        p.setProperty("rainbow", Boolean.toString(rainbow));
        p.setProperty("fps", Boolean.toString(showFps));
        p.setProperty("coords", Boolean.toString(showCoords));
        p.setProperty("keys", Boolean.toString(showKeystrokes));
        p.setProperty("armor", Boolean.toString(showArmor));
        p.setProperty("elytraAutoFire", Boolean.toString(elytraAutoFire));
        p.setProperty("elytraRange", Integer.toString(elytraRange));
        p.setProperty("elytraLeadTicks", Integer.toString(elytraLeadTicks));
        try {
            Files.createDirectories(FILE.getParent());
            try (OutputStream out = Files.newOutputStream(FILE)) { p.store(out, "AnarchyClient settings"); }
        } catch (IOException ignored) {}
    }
}
