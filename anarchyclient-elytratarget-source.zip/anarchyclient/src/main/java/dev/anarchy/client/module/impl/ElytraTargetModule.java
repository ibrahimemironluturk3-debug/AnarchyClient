package dev.anarchy.client.module.impl;

import dev.anarchy.client.config.ClientConfig;
import dev.anarchy.client.module.Module;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/** In-game Elytra targeting helper. Only runs while the local player is gliding. */
public final class ElytraTargetModule extends Module {
    private int fireCooldown;

    public ElytraTargetModule() {
        super("ElytraTarget");
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || !mc.player.isGliding()) return;

        PlayerEntity target = mc.world.getPlayers().stream()
                .filter(p -> p != mc.player && p.isAlive() && !p.isSpectator())
                .filter(p -> mc.player.squaredDistanceTo(p) <= (double) ClientConfig.elytraRange * ClientConfig.elytraRange)
                .min((a, b) -> Double.compare(mc.player.squaredDistanceTo(a), mc.player.squaredDistanceTo(b)))
                .orElse(null);
        if (target == null) return;

        // Predict a short distance ahead using the target's current movement vector.
        Vec3d predicted = target.getPos().add(target.getVelocity().multiply(ClientConfig.elytraLeadTicks));
        Vec3d delta = predicted.subtract(mc.player.getEyePos());
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float yaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontal));
        mc.player.setYaw(yaw);
        mc.player.setPitch(pitch);

        if (fireCooldown > 0) fireCooldown--;
        if (!ClientConfig.elytraAutoFire || fireCooldown > 0) return;

        // Use a firework already present in the hotbar; do not create or consume other items.
        for (int slot = 0; slot < 9; slot++) {
            if (mc.player.getInventory().getStack(slot).isOf(Items.FIREWORK_ROCKET)) {
                mc.player.getInventory().setSelectedSlot(slot);
                mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
                fireCooldown = 12;
                break;
            }
        }
    }

    @Override
    protected void onDisable() {
        fireCooldown = 0;
    }
}
