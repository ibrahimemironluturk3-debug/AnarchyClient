package dev.anarchy.client.gui;

import dev.anarchy.client.config.ClientConfig;
import dev.anarchy.client.module.Module;
import dev.anarchy.client.module.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;

public class ClickGuiScreen extends Screen {
    private final ModuleManager manager;
    private int page = 0;
    private Module waitingForKey;
    private static final int[] COLORS = {0xFF8B5CF6, 0xFF38BDF8, 0xFF22C55E, 0xFFF97316, 0xFFEC4899, 0xFFE5E7EB};

    public ClickGuiScreen(ModuleManager manager) {
        super(Text.literal("AnarchyClient"));
        this.manager = manager;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        int x = (width - 430) / 2, y = (height - 310) / 2;
        int accent = ClientConfig.rainbow ? rainbowColor() : ClientConfig.accent;
        ctx.fill(0, 0, width, height, 0x99000000);
        ctx.fill(x, y, x + 430, y + 310, 0xF0111420);
        ctx.fill(x, y, x + 430, y + 3, accent);
        ctx.fill(x, y, x + 112, y + 270, 0xF0191D2B);
        ctx.drawTextWithShadow(textRenderer, "ANARCHY", x + 16, y + 16, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer, "CLIENT  /  1.0", x + 16, y + 29, 0xFF9299AA);
        String[] tabs = {"Modules", "Visuals", "Theme"};
        for (int i = 0; i < tabs.length; i++) {
            int ty = y + 58 + i * 29;
            if (page == i) ctx.fill(x + 8, ty - 5, x + 104, ty + 17, 0xFF30364A);
            ctx.drawTextWithShadow(textRenderer, tabs[i], x + 18, ty, page == i ? accent : 0xFFB7BDCA);
        }
        ctx.drawTextWithShadow(textRenderer, page == 0 ? "MODULES" : page == 1 ? "HUD VISUALS" : "APPEARANCE", x + 132, y + 18, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer, "Right Shift  •  Close", x + 300, y + 19, 0xFF858DA0);
        if (page == 0) renderModules(ctx, x, y, accent);
        else if (page == 1) renderVisuals(ctx, x, y, accent);
        else renderTheme(ctx, x, y, accent);
        ctx.drawTextWithShadow(textRenderer, "Settings save automatically", x + 132, y + 290, 0xFF777F91);
        super.render(ctx, mouseX, mouseY, delta);
    }

    private void renderModules(DrawContext ctx, int x, int y, int accent) {
        List<Module> modules = manager.getModules();
        int row = 0;
        for (Module module : modules) {
            int ry = y + 48 + row * 29;
            if (ry > y + 225) break;
            ctx.fill(x + 130, ry, x + 414, ry + 23, 0xFF202638);
            ctx.drawTextWithShadow(textRenderer, module.getName(), x + 141, ry + 7, 0xFFE7EAF0);
            String keyLabel = waitingForKey == module ? "PRESS KEY" : manager.getKeyName(module);
            ctx.drawTextWithShadow(textRenderer, keyLabel, x + 315, ry + 7, waitingForKey == module ? 0xFFFFC857 : 0xFF9AA3B5);
            int color = module.isEnabled() ? accent : 0xFF626B7D;
            ctx.fill(x + 379, ry + 6, x + 402, ry + 17, color);
            ctx.fill(x + (module.isEnabled() ? 391 : 380), ry + 7, x + (module.isEnabled() ? 401 : 390), ry + 16, 0xFFFFFFFF);
            row++;
        }
    }

    private void renderVisuals(DrawContext ctx, int x, int y, int accent) {
        String[] names = {"FPS counter", "Coordinates", "Keystrokes", "Armor HUD", "Elytra auto-fire", "Target range (click to change)"};
        boolean[] values = {ClientConfig.showFps, ClientConfig.showCoords, ClientConfig.showKeystrokes, ClientConfig.showArmor, ClientConfig.elytraAutoFire, true};
        for (int i = 0; i < names.length; i++) {
            int ry = y + 53 + i * 37;
            ctx.fill(x + 130, ry, x + 414, ry + 27, 0xFF202638);
            ctx.drawTextWithShadow(textRenderer, names[i], x + 142, ry + 9, 0xFFE7EAF0);
            String value = i == 5 ? ClientConfig.elytraRange + " blocks" : (values[i] ? "ON" : "OFF");
            ctx.drawTextWithShadow(textRenderer, value, x + 350, ry + 9, values[i] ? accent : 0xFF8991A2);
        }
    }

    private void renderTheme(DrawContext ctx, int x, int y, int accent) {
        ctx.drawTextWithShadow(textRenderer, "ACCENT COLOR", x + 132, y + 53, 0xFFBFC5D2);
        for (int i = 0; i < COLORS.length; i++) {
            int cx = x + 136 + i * 43;
            ctx.fill(cx, y + 76, cx + 29, y + 105, COLORS[i]);
            if (!ClientConfig.rainbow && ClientConfig.accent == COLORS[i]) ctx.fill(cx - 2, y + 73, cx + 31, y + 76, 0xFFFFFFFF);
        }
        ctx.drawTextWithShadow(textRenderer, "RGB animation", x + 136, y + 128, 0xFFE7EAF0);
        ctx.drawTextWithShadow(textRenderer, ClientConfig.rainbow ? "ON" : "OFF", x + 365, y + 128, accent);
        ctx.drawTextWithShadow(textRenderer, "Custom RGB", x + 136, y + 163, 0xFFBFC5D2);
        ctx.drawTextWithShadow(textRenderer, "R - / +     G - / +     B - / +", x + 136, y + 184, 0xFF9299AA);
        ctx.drawTextWithShadow(textRenderer, String.format("#%06X", ClientConfig.accent & 0xFFFFFF), x + 136, y + 210, accent);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int x = (width - 430) / 2, y = (height - 310) / 2;
        if (button == 1 && page == 0 && mouseX >= x + 130 && mouseX <= x + 414) {
            int index = (int) ((mouseY - (y + 48)) / 29);
            if (index >= 0 && index < manager.getModules().size()) waitingForKey = manager.getModules().get(index);
            return true;
        }
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        if (mouseX >= x + 8 && mouseX <= x + 108 && mouseY >= y + 53 && mouseY <= y + 145) {
            page = Math.max(0, Math.min(2, (int) ((mouseY - (y + 53)) / 29))); return true;
        }
        if (page == 0 && mouseX >= x + 130 && mouseX <= x + 414) {
            int index = (int) ((mouseY - (y + 48)) / 29);
            if (index >= 0 && index < manager.getModules().size()) manager.getModules().get(index).toggle();
            return true;
        }
        if (page == 1 && mouseX >= x + 130 && mouseX <= x + 414) {
            int index = (int) ((mouseY - (y + 53)) / 37);
            switch (index) { case 0 -> ClientConfig.showFps = !ClientConfig.showFps; case 1 -> ClientConfig.showCoords = !ClientConfig.showCoords; case 2 -> ClientConfig.showKeystrokes = !ClientConfig.showKeystrokes; case 3 -> ClientConfig.showArmor = !ClientConfig.showArmor; case 4 -> ClientConfig.elytraAutoFire = !ClientConfig.elytraAutoFire; case 5 -> ClientConfig.elytraRange = ClientConfig.elytraRange >= 96 ? 24 : ClientConfig.elytraRange + 24; default -> {} }
            ClientConfig.save(); return true;
        }
        if (page == 2) {
            int swatch = (int) ((mouseX - (x + 136)) / 43);
            if (mouseY >= y + 73 && mouseY <= y + 110 && swatch >= 0 && swatch < COLORS.length) { ClientConfig.accent = COLORS[swatch]; ClientConfig.rainbow = false; }
            else if (mouseY >= y + 118 && mouseY <= y + 145) ClientConfig.rainbow = !ClientConfig.rainbow;
            else if (mouseY >= y + 175 && mouseY <= y + 205) {
                int relativeX = (int) mouseX - (x + 136);
                int channel = relativeX / 90;
                int step = relativeX % 90 < 45 ? -16 : 16;
                if (channel < 0 || channel > 2) return true;
                int a = ClientConfig.accent;
                int r = Math.max(0, Math.min(255, ((a >> 16) & 255) + (channel == 0 ? step : 0)));
                int g = Math.max(0, Math.min(255, ((a >> 8) & 255) + (channel == 1 ? step : 0)));
                int b = Math.max(0, Math.min(255, (a & 255) + (channel == 2 ? step : 0)));
                ClientConfig.accent = 0xFF000000 | r << 16 | g << 8 | b;
            }
            ClientConfig.save(); return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(net.minecraft.client.input.KeyInput input) {
        if (waitingForKey != null) {
            int keyCode = input.key();
            if (keyCode == 256) waitingForKey = null;
            else { manager.rebind(waitingForKey, keyCode); waitingForKey = null; }
            return true;
        }
        return super.keyPressed(input);
    }

    private int rainbowColor() {
        float hue = (System.currentTimeMillis() % 6000L) / 6000f;
        float h = hue * 6f; int sector = (int) h; float f = h - sector;
        float q = 1f - 0.75f * f, t = 1f - 0.75f * (1f - f);
        float r, g, b;
        switch (sector % 6) {
            case 0 -> { r = 1f; g = t; b = 0.25f; }
            case 1 -> { r = q; g = 1f; b = 0.25f; }
            case 2 -> { r = 0.25f; g = 1f; b = t; }
            case 3 -> { r = 0.25f; g = q; b = 1f; }
            case 4 -> { r = t; g = 0.25f; b = 1f; }
            default -> { r = 1f; g = 0.25f; b = q; }
        }
        return 0xFF000000 | ((int)(r * 255) << 16) | ((int)(g * 255) << 8) | (int)(b * 255);
    }

    @Override public boolean shouldPause() { return false; }
}
