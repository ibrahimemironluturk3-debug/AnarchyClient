package dev.anarchy.client.module.impl;

import dev.anarchy.client.module.Module;

public class SprintModule extends Module {
    public SprintModule() { super("Sprint"); }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (mc.options.forwardKey.isPressed() && !mc.player.horizontalCollision) {
            mc.player.setSprinting(true);
        }
    }
}
