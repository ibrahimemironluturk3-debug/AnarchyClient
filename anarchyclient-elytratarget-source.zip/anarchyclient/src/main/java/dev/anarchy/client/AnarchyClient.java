package dev.anarchy.client;

import dev.anarchy.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;

public class AnarchyClient implements ClientModInitializer {
    public static final ModuleManager MODULES = new ModuleManager();

    @Override
    public void onInitializeClient() {
        MODULES.init();
    }
}
