package dev.anarchy.client.module.impl;

import dev.anarchy.client.module.Module;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Difficulty;
import net.minecraft.world.RaycastContext;

import java.util.HashSet;
import java.util.Set;

/**
 * Basit ve güvenli CrystalAura.
 * Her döngüde: en iyi crystal'ı kır -> en iyi yere yeni crystal koy.
 * Ayarlar aşağıdaki sabitlerden değiştirilir.
 */
public class CrystalAuraModule extends Module {
    // ---- AYARLAR ----
    private static final double TARGET_RANGE = 12.0;     // hedef arama mesafesi
    private static final double PLACE_RANGE = 4.5;       // crystal koyma mesafesi
    private static final double BREAK_RANGE = 3.0;       // crystal kırma mesafesi (vanilla limiti 3)
    private static final float MIN_TARGET_DAMAGE = 5.0f; // hedefe en az bu kadar hasar
    private static final float MAX_SELF_DAMAGE = 7.0f;   // kendine en fazla bu kadar hasar
    private static final float SAFETY_BUFFER = 2.0f;     // kendi canından bu kadar pay bırak
    private static final int DELAY_TICKS = 1;            // 1 = her 2 tickte bir işlem

    private int cooldown;

    public CrystalAuraModule() { super("CrystalAura"); }

    @Override
    protected void onEnable() { cooldown = 0; }

    @Override
    public void onTick() {
        ClientPlayerEntity me = mc.player;
        if (me == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null || !me.isAlive() || me.isSpectator()) return;
        if (cooldown > 0) { cooldown--; return; }

        PlayerEntity target = findTarget(me);
        if (target == null) return;

        Set<Integer> broken = new HashSet<>();
        boolean acted = breakBest(me, target, broken);
        acted |= placeBest(me, target, broken);
        if (acted) cooldown = DELAY_TICKS;
    }

    // ---------- hedef ----------
    private PlayerEntity findTarget(ClientPlayerEntity me) {
        PlayerEntity best = null;
        double bestDist = TARGET_RANGE * TARGET_RANGE;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == me || !p.isAlive() || p.isCreative() || p.isSpectator()) continue;
            double d = me.squaredDistanceTo(p);
            if (d < bestDist) { bestDist = d; best = p; }
        }
        return best;
    }

    // ---------- kırma ----------
    private boolean breakBest(ClientPlayerEntity me, PlayerEntity target, Set<Integer> broken) {
        Vec3d eye = eye(me);
        Box search = me.getBoundingBox().expand(BREAK_RANGE + 2.0);
        EndCrystalEntity best = null;
        float bestScore = -1f;

        for (EndCrystalEntity c : mc.world.getEntitiesByClass(EndCrystalEntity.class, search, Entity::isAlive)) {
            if (distToBox(eye, c.getBoundingBox()) > BREAK_RANGE) continue;
            float score = evaluate(me, target, new Vec3d(c.getX(), c.getY(), c.getZ()));
            if (score > bestScore) { bestScore = score; best = c; }
        }
        if (best == null) return false;

        mc.interactionManager.attackEntity(me, best);
        me.swingHand(Hand.MAIN_HAND);
        broken.add(best.getId());
        return true;
    }

    // ---------- koyma ----------
    private boolean placeBest(ClientPlayerEntity me, PlayerEntity target, Set<Integer> broken) {
        Hand hand;
        int slot = -1;
        if (me.getOffHandStack().isOf(Items.END_CRYSTAL)) {
            hand = Hand.OFF_HAND;
        } else {
            hand = Hand.MAIN_HAND;
            if (!me.getMainHandStack().isOf(Items.END_CRYSTAL)) {
                slot = findHotbarCrystal(me);
                if (slot == -1) return false;
            }
        }

        Vec3d eye = eye(me);
        BlockPos origin = BlockPos.ofFloored(eye);
        int r = (int) Math.ceil(PLACE_RANGE);
        BlockPos best = null;
        float bestScore = -1f;
        BlockPos.Mutable pos = new BlockPos.Mutable();

        for (int x = -r; x <= r; x++) {
            for (int y = -r; y <= r; y++) {
                for (int z = -r; z <= r; z++) {
                    pos.set(origin.getX() + x, origin.getY() + y, origin.getZ() + z);

                    BlockState state = mc.world.getBlockState(pos);
                    if (!state.isOf(Blocks.OBSIDIAN) && !state.isOf(Blocks.BEDROCK)) continue;

                    Vec3d top = new Vec3d(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5);
                    if (eye.distanceTo(top) > PLACE_RANGE) continue;

                    BlockPos above = pos.up();
                    if (!mc.world.isAir(above) || !mc.world.isAir(above.up())) continue;

                    // koyduktan sonra kırabilmem lazım
                    Box crystalBox = new Box(top.x - 1, top.y, top.z - 1, top.x + 1, top.y + 2, top.z + 1);
                    if (distToBox(eye, crystalBox) > BREAK_RANGE) continue;

                    // yerde entity var mı (az önce kırdığımız crystal hariç)
                    Box placeBox = new Box(above.getX(), above.getY(), above.getZ(),
                            above.getX() + 1, above.getY() + 2, above.getZ() + 1);
                    boolean blocked = false;
                    for (Entity en : mc.world.getOtherEntities(null, placeBox)) {
                        if (en instanceof EndCrystalEntity && broken.contains(en.getId())) continue;
                        blocked = true;
                        break;
                    }
                    if (blocked) continue;

                    float score = evaluate(me, target, top);
                    if (score > bestScore) { bestScore = score; best = pos.toImmutable(); }
                }
            }
        }
        if (best == null) return false;

        int prevSlot = me.getInventory().getSelectedSlot();
        if (slot != -1) me.getInventory().setSelectedSlot(slot);

        BlockHitResult hit = new BlockHitResult(
                new Vec3d(best.getX() + 0.5, best.getY() + 1.0, best.getZ() + 0.5),
                Direction.UP, best, false);
        ActionResult result = mc.interactionManager.interactBlock(me, hand, hit);
        if (result.isAccepted()) me.swingHand(hand);

        if (slot != -1) me.getInventory().setSelectedSlot(prevSlot);
        return result.isAccepted();
    }

    private int findHotbarCrystal(ClientPlayerEntity me) {
        for (int i = 0; i < 9; i++) {
            if (me.getInventory().getStack(i).isOf(Items.END_CRYSTAL)) return i;
        }
        return -1;
    }

    // ---------- hasar hesabı ----------
    /** -1 = bu crystal uygun değil, aksi halde skor (yüksek = iyi). */
    private float evaluate(ClientPlayerEntity me, PlayerEntity target, Vec3d crystal) {
        float dmgTarget = damage(crystal, target);
        float targetHp = target.getHealth() + target.getAbsorptionAmount();
        boolean kills = dmgTarget >= targetHp;
        if (!kills && dmgTarget < MIN_TARGET_DAMAGE) return -1f;

        float dmgSelf = damage(crystal, me);
        float myHp = me.getHealth() + me.getAbsorptionAmount();
        if (dmgSelf + SAFETY_BUFFER >= myHp) return -1f;           // asla ölme
        if (!kills && dmgSelf > MAX_SELF_DAMAGE) return -1f;

        return dmgTarget - dmgSelf * 0.5f + (kills ? 100f : 0f);
    }

    /** Vanilla crystal patlama hasarı (zırh dahil, büyü/efekt hariç => muhafazakar). */
    private float damage(Vec3d src, LivingEntity e) {
        Difficulty diff = mc.world.getDifficulty();
        if (diff == Difficulty.PEACEFUL) return 0f;

        Vec3d ep = new Vec3d(e.getX(), e.getY(), e.getZ());
        double dist = ep.distanceTo(src) / 12.0;
        if (dist > 1.0) return 0f;

        double impact = (1.0 - dist) * exposure(src, e);
        float dmg = (float) ((impact * impact + impact) / 2.0 * 7.0 * 12.0 + 1.0);

        if (diff == Difficulty.EASY) dmg = Math.min(dmg / 2f + 1f, dmg);
        else if (diff == Difficulty.HARD) dmg = dmg * 3f / 2f;

        float armor = e.getArmor();
        float toughness = (float) e.getAttributeValue(EntityAttributes.ARMOR_TOUGHNESS);
        float f = 2f + toughness / 4f;
        float reduction = MathHelper.clamp(armor - dmg / f, armor * 0.2f, 20f);
        return Math.max(0f, dmg * (1f - reduction / 25f));
    }

    /** Basit görüş hesabı: ayak / gövde / kafa noktalarından 3 ışın. */
    private double exposure(Vec3d src, LivingEntity e) {
        Box b = e.getBoundingBox();
        double[] ys = { b.minY + 0.1, (b.minY + b.maxY) / 2.0, b.maxY - 0.1 };
        int visible = 0;
        for (double y : ys) {
            Vec3d to = new Vec3d(e.getX(), y, e.getZ());
            BlockHitResult r = mc.world.raycast(new RaycastContext(src, to,
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, e));
            if (r.getType() == HitResult.Type.MISS) visible++;
        }
        return visible / 3.0;
    }

    // ---------- yardımcılar ----------
    private static Vec3d eye(ClientPlayerEntity p) {
        return new Vec3d(p.getX(), p.getEyeY(), p.getZ());
    }

    private static double distToBox(Vec3d p, Box b) {
        double dx = MathHelper.clamp(p.x, b.minX, b.maxX) - p.x;
        double dy = MathHelper.clamp(p.y, b.minY, b.maxY) - p.y;
        double dz = MathHelper.clamp(p.z, b.minZ, b.maxZ) - p.z;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
}
