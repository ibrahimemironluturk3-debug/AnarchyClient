package dev.anarchy.client.module.impl;

import dev.anarchy.client.module.Module;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

public class FlyModule extends Module {
    private int ticks;

    public FlyModule() { super("Fly"); }

    @Override
    protected void onEnable() { ticks = 0; }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;

        p.getAbilities().allowFlying = true;
        p.getAbilities().flying = true;
        p.getAbilities().setFlySpeed(0.08f);

        // Vanilla "Flying is not enabled" kick'ini engellemek için anti-kick
        if (++ticks >= 30 && mc.getNetworkHandler() != null) {
            ticks = 0;
            double x = p.getX(), y = p.getY(), z = p.getZ();
            mc.getNetworkHandler().sendPacket(
                    new PlayerMoveC2SPacket.PositionAndOnGround(x, y - 0.05, z, false, p.horizontalCollision));
            mc.getNetworkHandler().sendPacket(
                    new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, false, p.horizontalCollision));
        }
    }

    @Override
    protected void onDisable() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        p.getAbilities().flying = false;
        p.getAbilities().allowFlying = p.isCreative() || p.isSpectator();
    }
}
