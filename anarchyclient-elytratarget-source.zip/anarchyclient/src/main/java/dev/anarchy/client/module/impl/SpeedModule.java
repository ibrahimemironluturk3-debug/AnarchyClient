package dev.anarchy.client.module.impl;

import dev.anarchy.client.module.Module;
import net.minecraft.client.network.ClientPlayerEntity;

public class SpeedModule extends Module {
    private static final double SPEED = 0.35;

    public SpeedModule() { super("Speed"); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;

        float f = (mc.options.forwardKey.isPressed() ? 1 : 0) - (mc.options.backKey.isPressed() ? 1 : 0);
        float s = (mc.options.leftKey.isPressed() ? 1 : 0) - (mc.options.rightKey.isPressed() ? 1 : 0);
        if (f == 0 && s == 0) return;

        double yaw = Math.toRadians(p.getYaw());
        double dx = -Math.sin(yaw) * f + Math.cos(yaw) * s;
        double dz = Math.cos(yaw) * f + Math.sin(yaw) * s;
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len == 0) return;

        p.setVelocity(dx / len * SPEED, p.getVelocity().y, dz / len * SPEED);
    }
}
